import React, {useState} from 'react';
import {View, TextInput, StyleSheet, Text, Alert} from 'react-native';
import {Ionicons} from '@expo/vector-icons';

const KeyboardType = () => {
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [fname, setfirstName] = useState('');
  const [lname, setlastName] = useState('');
  const [password, setPassword] = useState('');
  const [text, setText] = useState('');
  const HandleSubmit= () => {
  Alert.alert(
    'Submitted Text:',
  `First Name: ${fname} \nLast Name: ${lname} \nEmail Address: ${email} \nPhone Number: ${phone}`)
  };

  const [error, setError] = useState('');
  const validateEmail = (text) => {
  setEmail(text)
  if(!text.includes('@')){
    setError('Invalid Email address');
  }
  else{
    setError('');
  }
};

  return(
    <View style ={styles.container}>
    <View style ={styles.inputContainer}>
    <Ionicons name="person" size={20} color="gray" style={styles.icon}/>
       <TextInput  
       style ={styles.input}
        placeholder="First Name: "
        keyboardType="first-name"
        autoFocus={true}
        onChangeText={(text) => setfirstName(text)} />
    </View>
    <View style ={styles.inputContainer}>
    <Ionicons name="person" size={20} color="gray" style={styles.icon}/>
       <TextInput  
       style ={styles.input}
        placeholder="Last Name: "
        keyboardType="last-name"
        autoFocus={true}
        onChangeText={(text) => setlastName(text)}/> 
      </View>
      <View style ={styles.inputContainer}>
      <Ionicons name="mail" size={20} color="gray" style={styles.icon}/>
       <TextInput  
       style ={styles.input}
        placeholder="Email Address: "
        keyboardType="email-address"
        autoFocus={true}
        onChangeText={validateEmail}/>
       {error ? <Text>{error}</Text> : null}
       </View>
       <View style ={styles.inputContainer}>
       <Ionicons name="call" size={20} color="gray" style={styles.icon}/>
       <TextInput  
       style ={styles.input}
        placeholder="Phone Number: "
        keyboardType="phone-pad"
        autoFocus={true}
        onChangeText={(text) => setPhone(text)}/>
        </View>
        <View style ={styles.inputContainer}>
        <Ionicons name="eye" size={20} color="gray" style={styles.icon}/>
        <TextInput  
       style ={styles.input}
        placeholder="Enter Password: "
        autoFocus={true}
        maxLength={10}
        secureTextEntry ={true}
        onChangeText={(value) => setPassword(value)}
        returnKeyType="done"
        onSubmitEditing={HandleSubmit}/>
        </View>
        <Text style ={styles.displayText}> remaining {10 - text.length} characters </Text>
       <Text style ={styles.displayText}>
       Password Lenght: {password.length}
       </Text>
   </View>
  );
};



const styles=StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
 
  icon: {
    marginRigth: 10,
  },
  inputContainer: {
    flexDirection: "row",
    alignItems: 'center',
    width: '80%',
    borderColor: 'gray',
    borderWidth: 1, 
    paddingHorizontal: 10,
    marginVertical: 15,
    borderRadius: 5,
    justifyContent: 'center',
  },

  input: {
    height: 40,
    flex: 1,
    fontSize: 16,
  }
});



export default KeyboardType;
