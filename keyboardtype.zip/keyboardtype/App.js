import React, {useState} from 'react';
import {View, TextInput, StyleSheet, Text } from 'react-native';

const KeyboardType = () => {
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');

  return(
   <View style ={styles.container}>
       <TextInput  
       style ={styles.input}
        placeholder="Enter Email: "
        keyboardType="email-address"
        onChangeText={(text) => setEmail(text)}
       /> 
       <TextInput  
       style ={styles.input}
        placeholder="Enter Phone Number: "
        keyboardType="phone-pad"
        onChangeText={(text) => setPhone(text)}
       /> 
   </View>
  );
};

const BasicTextInput = () => {

  return(
   <View style ={styles.container}>
       <TextInput  
       style ={styles.input}
        placeholder="Type Here..."
       /> 
   </View>
  );
};

const styles=StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  input: {
    heigh: 40,
    width: '80%',
    borderColor: 'gray',
    borderWidth: 1, 
    paddingHorizontal: 10,
    borderRadius: 5,
    marginVertical: 10
  },


});



export default KeyboardType;
