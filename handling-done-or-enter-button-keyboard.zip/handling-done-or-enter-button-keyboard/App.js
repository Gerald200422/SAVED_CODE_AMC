import React, {useState} from 'react';
import {View, TextInput, StyleSheet, Alert } from 'react-native';

const SubmitExample= () => {
  const [text, setText] = useState('');

const HandleSubmit= () => {
  Alert.alert('Submitted Text:', text)

};

  return(
   <View style ={styles.container}>
       <TextInput  
       style ={styles.input}
        placeholder="Press Enter after Typing..."
        onChangeText={(value) => setText(value)}
        returnKeyType="done"
        onSubmitEditing={HandleSubmit}
       /> 

   </View>
  );
};

const BasicTextInput = () => {

  return(
   <View style ={styles.container}>
       <TextInput  
       style ={styles.input}
        placeholder="Type Here..."
       /> 
   </View>
  );
};

const styles=StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center'
  },
  input: {
    heigh: 40,
    width: '80%',
    borderColor: 'gray',
    borderWidth: 1, 
    paddingHorizontal: 10,
    borderRadius: 5
  },
  displayText: {
    marginTop: 10,
    fontSize: 18

  }


});



export default SubmitExample;
