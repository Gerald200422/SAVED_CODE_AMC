import React, {useState} from 'react';
import {View, TextInput, StyleSheet, Text } from 'react-native';

const HandleInputExample= () => {
  

  return(
   <View style ={styles.container}>
       <TextInput  
       style ={styles.input}
       value = "This is read-only"
       editable={false}
    
       /> 
  
   </View>
  );
};


const styles=StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center'
  },
  input: {
    heigh: 40,
    width: '80%',
    borderColor: 'gray',
    borderWidth: 1, 
    paddingHorizontal: 10,
    borderRadius: 5
  },
});



export default HandleInputExample;
