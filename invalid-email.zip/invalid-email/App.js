import React, {useState} from 'react';
import {View, TextInput, StyleSheet, Text } from 'react-native';

const ErrorstyleInput= () => {
  const [email, setEmail] = useState('');
  const [error, setError] = useState('');

const validateEmail = (text) => {
  setEmail(text)
  if(!text.includes('@')){
    setError('Invalid Email address');
  }
  else{
    setError('');
  }
};

  return(
   <View style ={styles.container}>
       <TextInput  
       style ={styles.input}
        placeholder="Enter Email: "
        keyboardType="email-address"
        onChangeText={validateEmail}
       /> 
       {error ? <Text>{error}</Text> : null}
   </View>
  );
};

const BasicTextInput = () => {

  return(
   <View style ={styles.container}>
       <TextInput  
       style ={styles.input}
        placeholder="Type Here..."
       /> 
   </View>
  );
};

const styles=StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  input: {
    heigh: 40,
    width: '80%',
    borderColor: 'gray',
    borderWidth: 1, 
    paddingHorizontal: 10,
    borderRadius: 5,
    marginVertical: 10
  },


});



export default ErrorstyleInput;
